/*
 * Copyright 2016-2026 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file    Blinky Hello World.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL46Z4.h"
#include "fsl_debug_console.h"

// Simple delay function for the 90-degree turn
void delay(void) {
    for (volatile int i = 0; i < 1500000*2 ; i++);
}

int main(void) {
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();

    // 1. Enable Clocks for Port B, and C
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK;

    // 2. Configure Motor Pins as GPIO (ALT1)
    // Left Motor: PTB0, PTB1 | Right Motor: PTC1, PTC2
    PORTB->PCR[0] = PORT_PCR_MUX(1);
    PORTB->PCR[1] = PORT_PCR_MUX(1);
    PORTC->PCR[1] = PORT_PCR_MUX(1);
    PORTC->PCR[2] = PORT_PCR_MUX(1);

    // Set Motor Pins as Outputs
    PTB->PDDR |= (1 << 0) | (1 << 1);
    PTC->PDDR |= (1 << 1) | (1 << 2);

    // 3. Configure Onboard Switches (SW1: PTC3, SW2: PTC12)
    // Note: MUX(1) for GPIO and PE/PS for Pull-up resistor
    PORTC->PCR[3] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
    PORTC->PCR[12] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;

    PTC->PDDR &= ~(1 << 3);
    PTC->PDDR &= ~(1 << 12);

    while(1) {
            // Check SW1 (Left Turn) - Switch is Active LOW
            if (!(PTC->PDIR & (1 << 3))) {
                // Rotate motors in opposite directions for a sharp turn
                PTB->PCOR = (1 << 0); PTB->PSOR = (1 << 1); // Left Motor BACK
                PTC->PCOR = (1 << 2); PTC->PSOR = (1 << 1); // Right Motor FORWARD
                delay(); // Adjust the loop count in delay() for a 90 degree turn
            }
            // Check SW2 (Right Turn) - Switch is Active LOW
            else if (!(PTC->PDIR & (1 << 12))) {
                // Rotate motors in opposite directions for a sharp turn
                PTB->PSOR = (1 << 0); PTB->PCOR = (1 << 1); // Left Motor FORWARD
                PTC->PSOR = (1 << 2); PTC->PCOR = (1 << 1); // Right Motor BACK
                delay();
            }
            else {
                // DEFAULT: Move Straight
                PTB->PSOR = (1 << 0); PTB->PCOR = (1 << 1);
                PTC->PCOR = (1 << 2); PTC->PSOR = (1 << 1);
            }
        }
    return 0;
}
